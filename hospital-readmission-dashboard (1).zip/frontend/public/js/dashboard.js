// =====================================================================
// dashboard.js  -  KPI cards, filters, sorting, pagination,
//                  risk summary and management insights.
// =====================================================================

let allEncounters = [];       // every encounter received from the API
let filteredEncounters = [];  // encounters left after search + filters + sort
let currentPage = 1;          // page currently shown in the table
let pageSize = 10;            // rows per page (10, 25 or 50)

// ---------- KPI cards and risk summary ----------

// Writes the statistics into the six KPI cards and the risk summary boxes.
function showStats(stats) {
  document.getElementById("kpiTotalPatients").textContent = stats.totalPatients;
  document.getElementById("kpiTotalEncounters").textContent = stats.totalEncounters;
  document.getElementById("kpiReadmissions").textContent = stats.readmissions30Day;
  document.getElementById("kpiReadmissionRate").textContent = stats.readmissionRate30Day + "%";
  document.getElementById("kpiHighRisk").textContent = stats.highRiskEncounters;
  document.getElementById("kpiAverageStay").textContent = stats.averageHospitalStay + " days";

  document.getElementById("summaryHigh").textContent = stats.highRiskEncounters;
  document.getElementById("summaryMedium").textContent = stats.mediumRiskEncounters;
  document.getElementById("summaryLow").textContent = stats.lowRiskEncounters;

  // Make it obvious when the numbers are sample values
  if (stats.isDemoData) {
    document.getElementById("demoBanner").classList.remove("hidden");
  }
}

// ---------- Filtering ----------

// Returns the age group name used by the Age Group filter.
function getAgeGroup(age) {
  if (age === null || age === undefined) { return "Other"; }
  if (age < 30) { return "0-30"; }
  if (age < 50) { return "30-50"; }
  if (age < 70) { return "50-70"; }
  if (age < 90) { return "70-90"; }
  return "Other";
}

// Gender and admission type have an "Other/Unknown" option.
// This returns the value itself if it is in the known list, otherwise "Other".
function getGroup(value, knownValues) {
  if (knownValues.includes(value)) {
    return value;
  }
  return "Other";
}

// Reads the search box and every filter, then updates the table.
// All filters work together: a record must pass EVERY check to stay.
function applyFilters() {
  const searchText = document.getElementById("dashboardSearch").value.trim().toLowerCase();
  const risk = document.getElementById("filterRisk").value;
  const ageGroup = document.getElementById("filterAge").value;
  const gender = document.getElementById("filterGender").value;
  const admission = document.getElementById("filterAdmission").value;
  const readmission = document.getElementById("filterReadmission").value;

  filteredEncounters = allEncounters.filter(function (encounter) {
    if (!encounter.patientId.toLowerCase().includes(searchText)) { return false; }
    if (risk !== "All" && encounter.riskCategory !== risk) { return false; }
    if (ageGroup !== "All" && getAgeGroup(encounter.age) !== ageGroup) { return false; }
    if (gender !== "All" && getGroup(encounter.gender, ["Male", "Female"]) !== gender) { return false; }
    if (admission !== "All" &&
        getGroup(encounter.admissionType, ["Emergency", "Urgent", "Elective"]) !== admission) { return false; }

    // Historical readmission: only the label "<30" means "within 30 days"
    const readmittedWithin30 = encounter.historicalReadmission === "<30";
    if (readmission === "Yes" && !readmittedWithin30) { return false; }
    if (readmission === "No" && readmittedWithin30) { return false; }

    return true;
  });

  sortEncounters();
  currentPage = 1;   // always go back to the first page after a change
  showPage();
  showActiveFilters();

  document.getElementById("matchCount").textContent =
    filteredEncounters.length + " matching records";
}

// ---------- Sorting ----------

// Sorts filteredEncounters using the option chosen in "Sort By".
function sortEncounters() {
  const sortBy = document.getElementById("sortBy").value;

  filteredEncounters.sort(function (a, b) {
    if (sortBy === "riskHigh") {
      return b.readmissionProbability - a.readmissionProbability;
    }
    if (sortBy === "riskLow") {
      return a.readmissionProbability - b.readmissionProbability;
    }
    if (sortBy === "patientId") {
      return a.patientId.localeCompare(b.patientId);
    }
    // sortBy === "age": youngest first, unknown ages at the end
    const ageA = a.age === null ? 999 : a.age;
    const ageB = b.age === null ? 999 : b.age;
    return ageA - ageB;
  });
}

// ---------- Pagination ----------

// Shows only the rows that belong to the current page.
function showPage() {
  let totalPages = Math.ceil(filteredEncounters.length / pageSize);
  if (totalPages === 0) { totalPages = 1; }

  const start = (currentPage - 1) * pageSize;
  const end = start + pageSize;
  const pageRecords = filteredEncounters.slice(start, end);

  renderTable("dashboardTableBody", pageRecords, "No records match the current search and filters.");

  document.getElementById("pageInfo").textContent = "Page " + currentPage + " of " + totalPages;
  document.getElementById("prevPageBtn").disabled = currentPage === 1;
  document.getElementById("nextPageBtn").disabled = currentPage === totalPages;
}

function goToNextPage() {
  currentPage = currentPage + 1;
  showPage();
}

function goToPreviousPage() {
  currentPage = currentPage - 1;
  showPage();
}

function changePageSize() {
  pageSize = Number(document.getElementById("pageSize").value);
  currentPage = 1;
  showPage();
}

// ---------- Active filter indicators ----------

// Shows a small label for every filter that is not set to "All".
function showActiveFilters() {
  const filters = [
    { label: "Patient ID", id: "dashboardSearch" },
    { label: "Risk", id: "filterRisk" },
    { label: "Age", id: "filterAge" },
    { label: "Gender", id: "filterGender" },
    { label: "Admission", id: "filterAdmission" },
    { label: "Readmission", id: "filterReadmission" }
  ];

  let html = "";

  filters.forEach(function (filter) {
    const element = document.getElementById(filter.id);
    const value = element.value.trim();
    if (value === "" || value === "All") { return; }

    // For a <select>, show the visible option text instead of the value
    let text = value;
    if (element.tagName === "SELECT") {
      text = element.options[element.selectedIndex].text;
    }
    html = html + '<span class="chip">' + filter.label + ": " + text + "</span>";
  });

  if (html === "") {
    html = '<span class="chip chip-muted">No filters active</span>';
  }
  document.getElementById("activeFilters").innerHTML = html;
}

// Puts every filter back to its default value.
function resetFilters() {
  document.getElementById("dashboardSearch").value = "";
  document.getElementById("globalSearch").value = "";
  document.getElementById("filterRisk").value = "All";
  document.getElementById("filterAge").value = "All";
  document.getElementById("filterGender").value = "All";
  document.getElementById("filterAdmission").value = "All";
  document.getElementById("filterReadmission").value = "All";
  document.getElementById("sortBy").value = "riskHigh";
  applyFilters();
}

// ---------- Breakdown panels (gender, age group, readmission status) ----------

// Counts how many records in a list pass a test function.
function countWhere(records, test) {
  return records.filter(test).length;
}

// Builds one coloured row such as:  Male   54 (53.8%)
function buildStatRow(label, count, total, cssClass) {
  let percent = 0;
  if (total > 0) {
    percent = (count * 100 / total).toFixed(1);
  }
  return '<div class="stat-row ' + cssClass + '"><span>' + label + "</span>" +
    "<strong>" + count + " (" + percent + "%)</strong></div>";
}

// Fills the three panels by counting the loaded records.
function showBreakdowns() {
  // 1. Gender - counted per unique patient (allPatients comes from patients.js)
  const totalPatients = allPatients.length;
  const male = countWhere(allPatients, function (p) { return p.gender === "Male"; });
  const female = countWhere(allPatients, function (p) { return p.gender === "Female"; });
  const otherGender = totalPatients - male - female;

  document.getElementById("genderList").innerHTML =
    buildStatRow("Male", male, totalPatients, "stat-sky") +
    buildStatRow("Female", female, totalPatients, "stat-pink") +
    buildStatRow("Other / Unknown", otherGender, totalPatients, "stat-grey");

  // 2. Age group - encounters in each 10-year band (0-10, 10-20, ... 90-100)
  const totalEncounters = allEncounters.length;
  let ageRows = "";

  for (let start = 0; start < 100; start = start + 10) {
    const count = countWhere(allEncounters, function (e) {
      return e.age !== null && e.age >= start && e.age < start + 10;
    });
    const percent = (count * 100 / totalEncounters).toFixed(1);
    ageRows = ageRows + "<tr><td>" + start + " &ndash; " + (start + 10) + "</td>" +
      "<td>" + count + " (" + percent + "%)</td></tr>";
  }

  const unknownAge = countWhere(allEncounters, function (e) { return e.age === null; });
  if (unknownAge > 0) {
    ageRows = ageRows + "<tr><td>Unknown</td><td>" + unknownAge + " (" +
      (unknownAge * 100 / totalEncounters).toFixed(1) + "%)</td></tr>";
  }
  document.getElementById("ageTableBody").innerHTML = ageRows;

  // 3. Historical readmission status - the three labels from the dataset
  const notReadmitted = countWhere(allEncounters, function (e) { return e.historicalReadmission === "NO"; });
  const after30 = countWhere(allEncounters, function (e) { return e.historicalReadmission === ">30"; });
  const within30 = countWhere(allEncounters, function (e) { return e.historicalReadmission === "<30"; });

  document.getElementById("readmissionList").innerHTML =
    buildStatRow("NO (No readmission)", notReadmitted, totalEncounters, "stat-green") +
    buildStatRow("&gt;30 days", after30, totalEncounters, "stat-sky") +
    buildStatRow("&lt;30 days", within30, totalEncounters, "stat-red");
}

// ---------- Management insights ----------

// Finds the value that appears most often in a list, e.g. ["A","B","A"] -> "A"
function findMostCommon(values) {
  const counts = {};
  let bestValue = "";
  let bestCount = 0;

  values.forEach(function (value) {
    counts[value] = (counts[value] || 0) + 1;
    if (counts[value] > bestCount) {
      bestCount = counts[value];
      bestValue = value;
    }
  });

  return { value: bestValue, count: bestCount };
}

// Average hospital stay (in days) of a list of encounters.
function averageStay(encounters) {
  if (encounters.length === 0) { return 0; }
  let total = 0;
  encounters.forEach(function (encounter) {
    total = total + encounter.hospitalStayDays;
  });
  return (total / encounters.length).toFixed(1);
}

// Builds the insight sentences by counting the loaded records.
// Nothing here is hardcoded: every number is calculated from the data.
function showInsights() {
  const highRisk = allEncounters.filter(function (e) { return e.riskCategory === "High"; });
  const lowRisk = allEncounters.filter(function (e) { return e.riskCategory === "Low"; });
  const insights = [];

  if (highRisk.length === 0) {
    insights.push("No encounters are currently classified as High Risk.");
  } else {
    // 1. Predicted risk and history are different things
    const notReadmitted = highRisk.filter(function (e) { return e.historicalReadmission !== "<30"; });
    insights.push(notReadmitted.length + " of " + highRisk.length +
      " High Risk encounters were not historically readmitted within 30 days, " +
      "so predicted risk and past readmission must be read separately.");

    // 2. Age group with the most high-risk encounters
    const ageGroup = findMostCommon(highRisk.map(function (e) { return getAgeGroup(e.age); }));
    insights.push("The age group with the most High Risk encounters is " + ageGroup.value +
      " (" + ageGroup.count + " encounters).");

    // 3. Most common admission type among high-risk encounters
    const admission = findMostCommon(highRisk.map(function (e) { return e.admissionType; }));
    insights.push(admission.value + " is the most common admission type among High Risk encounters (" +
      admission.count + " of " + highRisk.length + ").");

    // 4. Hospital stay comparison
    if (lowRisk.length > 0) {
      insights.push("Average hospital stay is " + averageStay(highRisk) +
        " days for High Risk encounters and " + averageStay(lowRisk) + " days for Low Risk encounters.");
    }
  }

  const items = insights.map(function (text) { return "<li>" + text + "</li>"; });
  document.getElementById("insightList").innerHTML = items.join("") +
    '<li class="insight-note">Observations are calculated from the records currently loaded (demo data).</li>';
}

// ---------- Loading the dashboard ----------

// Called once when the page opens. Fetches the data and fills the page.
function loadDashboard() {
  showTableMessage("dashboardTableBody", "Loading patient records...");

  getDashboardStats()
    .then(showStats)
    .catch(function (error) {
      console.log("Could not load dashboard statistics", error);
    });

  getPatients()
    .then(function (data) {
      allEncounters = data.encounters;

      if (data.isDemoData) {
        document.getElementById("demoBannerText").textContent =
          "All records, statistics and predictions on this page are temporary sample values, " +
          "not real model outputs. Model version label: " + data.modelVersion + ".";
      }

      buildPatientList(allEncounters);   // from patients.js
      applyFilters();
      showBreakdowns();
      showInsights();
    })
    .catch(function (error) {
      console.log("Could not load patient records", error);
      showTableMessage("dashboardTableBody", "Patient records could not be loaded. Please try again.");
    });
}

// ---------- Events ----------
document.getElementById("dashboardSearch").addEventListener("input", applyFilters);
document.getElementById("filterRisk").addEventListener("change", applyFilters);
document.getElementById("filterAge").addEventListener("change", applyFilters);
document.getElementById("filterGender").addEventListener("change", applyFilters);
document.getElementById("filterAdmission").addEventListener("change", applyFilters);
document.getElementById("filterReadmission").addEventListener("change", applyFilters);
document.getElementById("sortBy").addEventListener("change", applyFilters);
document.getElementById("resetFiltersBtn").addEventListener("click", resetFilters);
document.getElementById("pageSize").addEventListener("change", changePageSize);
document.getElementById("nextPageBtn").addEventListener("click", goToNextPage);
document.getElementById("prevPageBtn").addEventListener("click", goToPreviousPage);
