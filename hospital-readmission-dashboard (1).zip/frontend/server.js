// =====================================================================
// server.js - a small Express server that serves the frontend files.
// Run it with:  npm install   then   npm start
// =====================================================================

const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

// Serve everything inside the "public" folder (HTML, CSS, JS, demo JSON)
app.use(express.static(path.join(__dirname, "public")));

app.listen(PORT, function () {
  console.log("Dashboard running at http://localhost:" + PORT);
});
