// =====================================================================
// api.js  -  ALL data fetching lives in this file.
//
// Right now the functions read temporary DEMO JSON files from /data.
// When the FastAPI backend is ready, change ONLY the settings below.
// The rest of the application does not need to change.
// =====================================================================

// Set this to false when the real FastAPI endpoints are available.
const USE_DEMO_DATA = true;

// Address of the FastAPI backend (used only when USE_DEMO_DATA is false).
const API_BASE_URL = "http://localhost:8000";

// Small helper: fetch a URL and convert the response to a JavaScript object.
// It returns a Promise, so the caller uses .then() and .catch().
function fetchJson(url) {
  return fetch(url).then(function (response) {
    if (!response.ok) {
      throw new Error("Request failed: " + url);
    }
    return response.json();
  });
}

// GET /dashboard/stats  -  numbers for the six KPI cards and risk summary.
function getDashboardStats() {
  if (USE_DEMO_DATA) {
    return fetchJson("data/dashboard-stats.json");
  }
  return fetchJson(API_BASE_URL + "/dashboard/stats");
}

// GET /patients  -  the list of patient encounters.
// Each encounter already contains the prediction made by the Random Forest
// model (readmissionProbability, riskCategory, predictionTimestamp,
// modelVersion). The frontend never calculates a prediction itself.
function getPatients() {
  if (USE_DEMO_DATA) {
    return fetchJson("data/patients.json");
  }
  return fetchJson(API_BASE_URL + "/patients");
}

// GET /patients/{patient_id}  -  one patient (for the future profile page).
function getPatientById(patientId) {
  if (USE_DEMO_DATA) {
    return getPatients().then(function (data) {
      return data.encounters.filter(function (encounter) {
        return encounter.patientId === patientId;
      });
    });
  }
  return fetchJson(API_BASE_URL + "/patients/" + patientId);
}

// GET /monitoring/high-risk  -  high-risk encounters for the notification bell.
function getHighRiskEncounters() {
  if (USE_DEMO_DATA) {
    return getPatients().then(function (data) {
      return data.encounters.filter(function (encounter) {
        return encounter.riskCategory === "High";
      });
    });
  }
  return fetchJson(API_BASE_URL + "/monitoring/high-risk");
}
