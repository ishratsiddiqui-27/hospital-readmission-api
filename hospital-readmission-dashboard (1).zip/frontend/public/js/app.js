// =====================================================================
// app.js  -  header controls (global search, notifications, profile menu)
//            and starting the application.
// =====================================================================

const notificationMenu = document.getElementById("notificationMenu");
const profileMenu = document.getElementById("profileMenu");

// ---------- Global search ----------

// Typing in the header search filters the dashboard table by Patient ID.
function runGlobalSearch() {
  const searchText = document.getElementById("globalSearch").value;
  document.getElementById("dashboardSearch").value = searchText;
  showDashboardView();   // from patients.js
  applyFilters();        // from dashboard.js
}

// ---------- Notification bell ----------

// Fills the notification dropdown with the highest-risk encounters.
function loadNotifications() {
  getHighRiskEncounters()
    .then(function (encounters) {
      // Highest probability first
      encounters.sort(function (a, b) {
        return b.readmissionProbability - a.readmissionProbability;
      });

      document.getElementById("notificationCount").textContent = encounters.length;

      if (encounters.length === 0) {
        document.getElementById("notificationList").innerHTML =
          '<p class="dropdown-empty">No high-risk encounters awaiting review.</p>';
        return;
      }

      // Show only the first 6 so the dropdown stays small
      const items = encounters.slice(0, 6).map(function (encounter) {
        return '<a class="notification-item" href="profile.html?patientId=' + encounter.patientId +
          "&encounterId=" + encounter.encounterId + '">' +
          "<div><strong>" + encounter.patientId + "</strong>" +
          "<small>Encounter " + encounter.encounterId + " &middot; " + encounter.admissionType + "</small></div>" +
          '<span class="badge badge-high">' + formatProbability(encounter.readmissionProbability) + "</span></a>";
      });

      document.getElementById("notificationList").innerHTML = items.join("") +
        '<p class="dropdown-empty">Showing ' + items.length + " of " + encounters.length +
        " high-risk encounters (demo data)</p>";
    })
    .catch(function (error) {
      console.log("Could not load notifications", error);
      document.getElementById("notificationList").innerHTML =
        '<p class="dropdown-empty">Notifications could not be loaded.</p>';
    });
}

// ---------- Dropdown menus ----------

function toggleNotificationMenu(event) {
  event.stopPropagation();              // stop the document click below from closing it
  profileMenu.classList.add("hidden");  // only one menu open at a time
  notificationMenu.classList.toggle("hidden");
}

function toggleProfileMenu(event) {
  event.stopPropagation();
  notificationMenu.classList.add("hidden");
  profileMenu.classList.toggle("hidden");
}

// Clicking anywhere else on the page closes both menus.
function closeMenus() {
  notificationMenu.classList.add("hidden");
  profileMenu.classList.add("hidden");
}

// ---------- Events ----------
document.getElementById("globalSearch").addEventListener("input", runGlobalSearch);
document.getElementById("notificationBtn").addEventListener("click", toggleNotificationMenu);
document.getElementById("profileBtn").addEventListener("click", toggleProfileMenu);
document.addEventListener("click", closeMenus);

// ---------- Start the application ----------
loadDashboard();
loadNotifications();
