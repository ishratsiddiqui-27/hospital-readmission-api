// =====================================================================
// patients.js  -  the patient table (shared) and the "All Patients" view.
// =====================================================================

// One row per unique patient. Filled by buildPatientList().
let allPatients = [];

// ---------- Small formatting helpers ----------

// 0.624 becomes "62.4%"
function formatProbability(probability) {
  return (probability * 100).toFixed(1) + "%";
}

// Missing values are shown as "Unknown" instead of an empty cell
function showValue(value) {
  if (value === null || value === undefined || value === "") {
    return "Unknown";
  }
  return value;
}

// Turns the dataset label (<30, >30, NO) into a readable badge.
// This is what actually happened in the past, NOT the model prediction.
function buildHistoryBadge(label) {
  if (label === "<30") {
    return '<span class="badge badge-history-yes">Within 30 days (&lt;30)</span>';
  }
  if (label === ">30") {
    return '<span class="badge badge-history-no">After 30 days (&gt;30)</span>';
  }
  return '<span class="badge badge-history-no">Not readmitted</span>';
}

// ---------- Table rendering (used by BOTH tables) ----------

// Builds the HTML for one table row from one encounter object.
function buildTableRow(encounter) {
  const riskClass = "badge-" + encounter.riskCategory.toLowerCase();
  const profileLink = "profile.html?patientId=" + encounter.patientId +
    "&encounterId=" + encounter.encounterId;

  return "<tr>" +
    '<td><div class="patient-cell"><span class="patient-icon">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/></svg>' +
      "</span><div><strong>" + encounter.patientId + "</strong>" +
      "<small>Encounter " + encounter.encounterId + "</small></div></div></td>" +
    "<td>" + showValue(encounter.age) + "</td>" +
    "<td>" + showValue(encounter.gender) + "</td>" +
    "<td>" + showValue(encounter.race) + "</td>" +
    "<td>" + showValue(encounter.admissionType) + "</td>" +
    "<td>" + encounter.hospitalStayDays + " days</td>" +
    "<td>" + encounter.previousInpatientVisits + "</td>" +
    "<td>" + encounter.emergencyVisits + "</td>" +
    '<td class="probability">' + formatProbability(encounter.readmissionProbability) + "</td>" +
    '<td><span class="badge ' + riskClass + '">' + encounter.riskCategory + "</span></td>" +
    "<td>" + buildHistoryBadge(encounter.historicalReadmission) + "</td>" +
    '<td><a class="btn btn-primary btn-small" href="' + profileLink + '">View Profile</a></td>' +
    "</tr>";
}

// Fills a table body with rows. If there are no records it shows a message.
// tableBodyId  - id of the <tbody> to fill
// records      - array of encounter objects
// emptyMessage - text to show when the array is empty
function renderTable(tableBodyId, records, emptyMessage) {
  const tableBody = document.getElementById(tableBodyId);

  if (records.length === 0) {
    showTableMessage(tableBodyId, emptyMessage);
    return;
  }

  const rows = records.map(buildTableRow);
  tableBody.innerHTML = rows.join("");
}

// Shows one full-width message row (loading, empty or error state).
function showTableMessage(tableBodyId, message) {
  const tableBody = document.getElementById(tableBodyId);
  tableBody.innerHTML = '<tr><td colspan="12" class="table-message">' + message + "</td></tr>";
}

// ---------- All Patients view ----------

// One patient can have many encounters. This keeps only the most recent
// encounter (largest encounterId) for each Patient ID.
function buildPatientList(encounters) {
  const latestByPatient = {};

  encounters.forEach(function (encounter) {
    const saved = latestByPatient[encounter.patientId];
    if (saved === undefined || encounter.encounterId > saved.encounterId) {
      latestByPatient[encounter.patientId] = encounter;
    }
  });

  allPatients = Object.values(latestByPatient);

  // Show the list in Patient ID order
  allPatients.sort(function (a, b) {
    return a.patientId.localeCompare(b.patientId);
  });
}

// Filters the patient list using the text typed in the search box.
function searchPatients() {
  const searchText = document.getElementById("patientSearch").value.trim().toLowerCase();

  const matches = allPatients.filter(function (patient) {
    return patient.patientId.toLowerCase().includes(searchText);
  });

  renderTable("patientsTableBody", matches, "No patient matches this Patient ID.");
  document.getElementById("patientTotal").textContent = allPatients.length;

  if (searchText === "") {
    document.getElementById("patientMatchCount").textContent = "";
  } else {
    document.getElementById("patientMatchCount").textContent = matches.length + " matching patients";
  }
}

// Clears the search box and shows every patient again.
function resetPatientSearch() {
  document.getElementById("patientSearch").value = "";
  searchPatients();
}

// Hides the dashboard and shows the complete patient list.
function showPatientsView() {
  document.getElementById("dashboardView").classList.add("hidden");
  document.getElementById("patientsView").classList.remove("hidden");
  document.getElementById("navDashboard").classList.remove("nav-active");
  document.getElementById("navPatients").classList.add("nav-active");
  resetPatientSearch();
  window.scrollTo(0, 0);
}

// Hides the patient list and shows the dashboard again.
function showDashboardView() {
  document.getElementById("patientsView").classList.add("hidden");
  document.getElementById("dashboardView").classList.remove("hidden");
  document.getElementById("navPatients").classList.remove("nav-active");
  document.getElementById("navDashboard").classList.add("nav-active");
}

// ---------- Events ----------
document.getElementById("navPatients").addEventListener("click", showPatientsView);
document.getElementById("navDashboard").addEventListener("click", showDashboardView);
document.getElementById("viewPatientsBtn").addEventListener("click", showPatientsView);
document.getElementById("viewAllPatientsBtn").addEventListener("click", showPatientsView);
document.getElementById("backToDashboardBtn").addEventListener("click", showDashboardView);
document.getElementById("patientSearch").addEventListener("input", searchPatients);
document.getElementById("resetPatientSearchBtn").addEventListener("click", resetPatientSearch);
