# Hospital Readmission Intelligence Dashboard (Phase 1)

## How to run
1. Install Node.js.
2. Open a terminal in this folder.
3. `npm install`
4. `npm start`
5. Open http://localhost:3000

## Files
- `server.js` - Express server that serves the `public` folder.
- `public/index.html` - the dashboard page and the All Patients view.
- `public/profile.html` - placeholder for the future patient profile page.
- `public/css/style.css` - colours, navigation bar, cards, buttons, badges.
- `public/css/dashboard.css` - KPI cards, panels, filters, tables, pagination.
- `public/css/responsive.css` - tablet and phone layout.
- `public/js/api.js` - all data fetching. Set `USE_DEMO_DATA = false` and `API_BASE_URL` to use FastAPI.
- `public/js/patients.js` - shared table rendering and the All Patients view.
- `public/js/dashboard.js` - KPIs, panels, filters, sorting, pagination, insights.
- `public/js/app.js` - global search, notification bell, profile menu, start-up.
- `public/data/*.json` - temporary DEMO DATA (not real model output).
